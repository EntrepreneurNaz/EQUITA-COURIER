        <footer class="footer footer-1">
            <div class="footer-top">
                <div class="container text-center">
                    <div class="row ">
                        <div class="col-12 col-lg-3 col-xl-4">
                            <div class="footer-logo"><img class="footer-logo" src="../assets/images/logo/logo-light.png"
                                    alt="logo" /></div>
                        </div>
                        <div class="col-12 col-lg-9 col-xl-8">
                            
                        </div>
                    </div>
                </div>
            </div>

        </footer>
        <div class="backtop" id="back-to-top"><i class="fas fa-chevron-up"></i></div>
    </div>

    <script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script src="../assets/js/vendor/jquery-3.4.1.min.js"></script>
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/functions.js"></script>
</body>

<!-- Mirrored from demo.zytheme.com/equita/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 25 Jul 2022 12:43:14 GMT -->

</html>